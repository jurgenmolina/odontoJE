import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Principal {
    public static void main(String[] args) {

        Set<Campeon>campenes = new HashSet<>();

        Set<Habilidad> habilidades = new HashSet<>();
      Habilidad habilidad1 = new Habilidad("velocidad",  "rapidez",TipoHabilidad.ACTIVA );
      habilidades.add(habilidad1);
        Habilidad habilidad2 = new Habilidad("ataque",  "ataquecercano",TipoHabilidad.PASIVA);
        habilidades.add(habilidad2);
        //String nombre, String tirulo, String historia, Set<Habilidad> habilidades,
        //                   Rol rol, Dificultad dificultad

        //String nombre, String email, String usuario, Date fechaNacimiento,
        //                   String clave, Set<Campeon> campeones
        Usuario usuario = new Usuario("Manuel", "manuel@gmail.com",
                "manolo7",new Date(),"12345hhh" ,campenes);

        Campeon campeon1 = new Campeon("Ashe","Arquera_hielo","Antigua guerrera",
                habilidades, Rol.TIRADOR,Dificultad.MODERADA);
        usuario.agregarCampeon(campeon1);
        usuario.agregarCampeon(campeon1);

        Campeon campeon2 = new Campeon("thor","diosdelrayo","Thor es desterrado a la Tierra por su padre para que viva entre los hombres y descubra así el verdadero sentido de la humildad. Allí, sin sus poderes, Thor deberá enfrentarse a las fuerzas más oscuras que su mayor enemigo le enviará desde Asgard.",
                habilidades, Rol.TIRADOR,Dificultad.MODERADA);
        usuario.agregarCampeon(campeon2);

        campeon1.addHabilidad(new Habilidad("velocidad",  "rapidez",TipoHabilidad.ACTIVA ));


        System.out.println("***************imprimir informacion del usuario****************");
        usuario.imprimirInformacion();
        System.out.println("**************imprimir informacion de los campeones***********");
        usuario.ImprimirCampeones();

        System.out.println("**********cantidad de campeones*************");
        System.out.println(usuario.getCantidadCampeones());
    }
}
