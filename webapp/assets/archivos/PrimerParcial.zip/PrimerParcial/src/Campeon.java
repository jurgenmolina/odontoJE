
import java.util.*;

/**
 * 
 */
public class Campeon {

    /**
     * Default constructor
     */
    public Campeon() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String tirulo;

    /**
     * 
     */
    private String historia;



    /**
     * 
     */
    private Set<Habilidad> habilidades = new HashSet<Habilidad>();

    /**
     * 
     */
    private Rol rol;

    /**
     * 
     */
    private Dificultad dificultad;

    public Campeon(String nombre, String tirulo, String historia, Set<Habilidad> habilidades,
                   Rol rol, Dificultad dificultad) {
        this.nombre = nombre;
        this.tirulo = tirulo;
        this.historia = historia;
        this.habilidades = habilidades;
        this.rol = rol;
        this.dificultad = dificultad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTirulo() {
        return tirulo;
    }

    public void setTirulo(String tirulo) {
        this.tirulo = tirulo;
    }

    public String getHistoria() {
        return historia;
    }

    public void setHistoria(String historia) {
        this.historia = historia;
    }

    public Set<Habilidad> getHabilidades() {
        return habilidades;
    }

    public void setHabilidades(Set<Habilidad> habilidades) {
        this.habilidades = habilidades;
    }

    public void addHabilidad(Habilidad habilidad) {
         this.habilidades.add(habilidad);
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public Dificultad getDificultad() {
        return dificultad;
    }

    public void setDificultad(Dificultad dificultad) {
        this.dificultad = dificultad;
    }

    /**
     * @return
     */
    public void imprimirInformacion() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return "Campeon{" +
                "nombre='" + nombre + '\'' +
                ", tirulo='" + tirulo + '\'' +
                ", historia='" + historia + '\'' +
                ", habilidades=" + imprimirHabilidades() +
                ", rol=" + rol.getNombreRol() +
                ", dificultad=" + dificultad.getNombreDificultad() +
                '}';

    }
    private String imprimirHabilidades(){
        String retorno="";
        for (Habilidad hab:habilidades) {
            retorno += hab.toString();
        }
        return retorno;
    }
}