
import java.util.*;

/**
 * 
 */
public class Habilidad {

    /**
     * Default constructor
     */
    public Habilidad() {
    }

    /**
     * 
     */
    public String descripcion;

    /**
     * 
     */
    public String nombre;




    /**
     * 
     */
    public TipoHabilidad tipo;

    public Habilidad(String descripcion, String nombre, TipoHabilidad tipo) {
        this.descripcion = descripcion;
        this.nombre = nombre;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Habilidad{" +
                "descripcion='" + descripcion + '\'' +
                ", nombre='" + nombre + '\'' +
                ", tipo=" + tipo.getNombreTipoHabilidad() +
                '}';
    }
}