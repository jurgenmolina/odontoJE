import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DatosBasicosJugador extends JFrame
{
    public JPanel panelEtiqueta, panelEntradas, panelBotones;
    public JLabel nombre, email, usuario, fechaNacimiento, titulo;
    public JTextField txtNombre, txtEmail, txtUsuario, txtFecha;
    public JButton guardar, asociarCampeones, volver;
    private Cliente cliente;
    
        public DatosBasicosJugador(){
            cliente = new Cliente();
        setSize(600,400);
        setTitle("Menu Principal");
        setResizable(false);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        colocarPanel();
        colocarEtiquetas();
        colocarBotones();
        eventos();
    }
    
    public void colocarPanel(){
        //Panel Etiqueta
        panelEtiqueta = new JPanel();
        panelEtiqueta.setLayout(new GridLayout(1,1));
        panelEtiqueta.setPreferredSize( new Dimension(5,100));
        add(panelEtiqueta, BorderLayout.NORTH);
        //PanelEntradas
        panelEntradas = new JPanel();
        panelEntradas.setLayout(new GridLayout(4,2));
        panelEntradas.setPreferredSize( new Dimension(5,400));
        add(panelEntradas, BorderLayout.CENTER);
        this.getContentPane().add(panelEntradas);
        
        panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(1,3));
        panelBotones.setPreferredSize( new Dimension(5,100));
        add(panelBotones, BorderLayout.SOUTH);
        
    }
    
    public void colocarEtiquetas(){
        titulo = new JLabel();
        titulo.setText("Datos Básicos del jugador");
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.PLAIN, 20));
        panelEtiqueta.add(titulo);
        
        nombre = new JLabel("Nombre:");
        email = new JLabel("Email:");
        usuario = new JLabel("Usuario:");
        fechaNacimiento = new JLabel("Fecha Nac:");
        
        txtNombre = new JTextField();
        txtEmail = new JTextField();
        txtUsuario = new JTextField();
        txtFecha = new JTextField();
        
        panelEntradas.add(nombre);
        panelEntradas.add(txtNombre);
        panelEntradas.add(email);
        panelEntradas.add(txtEmail);
        panelEntradas.add(usuario);
        panelEntradas.add(txtUsuario);
        panelEntradas.add(fechaNacimiento);
        panelEntradas.add(txtFecha);
    }
    
    public void colocarBotones(){
        guardar = new JButton();
        guardar.setText("Guardar");
        guardar.setFont(new Font ("cooper black", 0, 15));
        panelBotones.add(guardar);
        
        asociarCampeones = new JButton();
        asociarCampeones.setText("Asociar campeones");
        asociarCampeones.setFont(new Font ("cooper black", 0, 12));
        panelBotones.add(asociarCampeones);
        
        volver = new JButton();
        volver.setText("Volver");
        volver.setFont(new Font ("cooper black", 0, 15));
        panelBotones.add(volver);
    }
    
    ActionListener asociarCampeon = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            AsociarCampeon obj = new AsociarCampeon();
            obj.setJugador(cliente.getJugadores().get(0));
            obj.setVisible(true);
            dispose();
        }
    
    };
    
    ActionListener volverAtras = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            MenuPrincipal obj = new MenuPrincipal();
            obj.setVisible(true);
            dispose();
        }
    
    };
    
    ActionListener guardarDatos = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
                try{
                SimpleDateFormat d = new SimpleDateFormat("dd/MM/yyyy");
                Date fecha = d.parse(txtFecha.getText());
                    
                Jugador player = new Jugador(txtNombre.getText(),txtEmail.getText(), txtUsuario.getText(), fecha);
                cliente.agregarJugador(player);
            
            JOptionPane.showMessageDialog(null ,"se a guardado exitosamente"); 
            }catch(Exception a){
                JOptionPane.showMessageDialog(null ,"Datos incorrectos");

            }
        }
    
    };
    
    
    public void eventos(){
        asociarCampeones.addActionListener(asociarCampeon);
        volver.addActionListener(volverAtras);
        guardar.addActionListener(guardarDatos);
    }
}
