import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegistrarCampeones extends JFrame
{
    public JPanel panelEtiqueta, panelEntradas, panelBotones;
    public JLabel nombre, titulo1, dificultad, habilidad, titulo;
    public JTextField txtNombre, txtTitulo;
    public JComboBox boxDif, boxHab;
    public JButton guardar, volver;
    private Dificultad d;
    private TipoHabilidad h;
    private Cliente cliente;
    
        public RegistrarCampeones(){
        setSize(400,400);
        setTitle("Registrar Campeones");
        setResizable(false);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        colocarPanel();
        colocarEtiquetas();
        colocarBotones();
        eventos();  
    }
    
    public void colocarPanel(){
        //Panel Etiqueta
        panelEtiqueta = new JPanel();
        panelEtiqueta.setLayout(new GridLayout(1,1));
        panelEtiqueta.setPreferredSize( new Dimension(5,100));
        add(panelEtiqueta, BorderLayout.NORTH);
        //PanelEntradas
        panelEntradas = new JPanel();
        panelEntradas.setLayout(new GridLayout(4,2));
        panelEntradas.setPreferredSize( new Dimension(5,200));
        add(panelEntradas, BorderLayout.CENTER);
        this.getContentPane().add(panelEntradas);
        
        panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(1,2));
        panelBotones.setPreferredSize( new Dimension(5,100));
        add(panelBotones, BorderLayout.SOUTH);
        
    }
    
    public void colocarEtiquetas(){
        titulo = new JLabel();
        titulo.setText("Datos básicos del Campeon");
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.PLAIN, 20));
        panelEtiqueta.add(titulo);
        
        nombre = new JLabel("Nombre:");
        titulo1 = new JLabel("Titulo:");
        dificultad = new JLabel("Dificultad:");
        habilidad = new JLabel("Habilidad:");
        
        txtNombre = new JTextField();
        txtTitulo = new JTextField();
        boxDif = new JComboBox(d.values());
        boxHab = new JComboBox(h.values());
        
        panelEntradas.add(nombre);
        panelEntradas.add(txtNombre);
        panelEntradas.add(titulo1);
        panelEntradas.add(txtTitulo);
        panelEntradas.add(dificultad);
        panelEntradas.add(boxDif);
        panelEntradas.add(habilidad);
        panelEntradas.add(boxHab);
        
    }
    
    public void colocarBotones(){
        guardar = new JButton();
        guardar.setText("Guardar");
        guardar.setFont(new Font ("cooper black", 0, 20));
        panelBotones.add(guardar);
        
        volver = new JButton();
        volver.setText("Volver");
        volver.setFont(new Font ("cooper black", 0, 20));
        panelBotones.add(volver);
    }
    
    ActionListener volverAtras = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            MenuPrincipal obj = new MenuPrincipal();
            obj.setVisible(true);
            dispose();
        }
    
    };
    
    ActionListener guardarDatos = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
                try{
                //Campeon campeon = new Campeon(txtNombre.getText(),txtTitulo.getText(), boxHab.getSelectedItem(),boxDif.getSelectedItem());
                //cliente.agregarCampeon(campeon);
            
            JOptionPane.showMessageDialog(null ,"se a guardado exitosamente"); 
            }catch(Exception a){
                JOptionPane.showMessageDialog(null ,"Datos incorrectos");

            }
        }
    
    };
    
    
    public void eventos(){
        guardar.addActionListener(guardarDatos);
        volver.addActionListener(volverAtras);
    }
}
