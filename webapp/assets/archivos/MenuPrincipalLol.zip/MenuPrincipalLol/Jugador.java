
import java.util.*;

/**
 *
 */
public class Jugador {

    /**
     * Default constructor
     */
    public Jugador() {
    }

    /**
     *
     */
    private String nombre;

    /**
     *
     */
    private String email;

    /**
     *
     */
    private String usuario;

    /**
     *
     */
    private Date fechaNacimiento;

    /**
     *
     */
    private String clave;

    /**
     *
     */
    private Set<Campeon> campeones;
    
    public Jugador(String nombre, String email, String usuario, Date fechaNacimiento) {
        this.nombre = nombre;
        this.email = email;
        this.usuario = usuario;
        this.fechaNacimiento = fechaNacimiento;
        this.campeones = campeones;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Set<Campeon> getCampeones() {
        return campeones;
    }

    public void setCampeones(Set<Campeon> campeones) {
        this.campeones = campeones;
    }



    /**
     * @return
     */
    public void imprimirInformacion() {
        System.out.println(toString());
    }

    /**
     * @return
     */
    public void ImprimirCampeones() {
        for (Campeon cap:campeones) {
            cap.imprimirInformacion();
        }

    }

    public void agregarCampeon (Campeon campeon){
        if(!this.campeones.contains(campeon)){
            this.campeones.add(campeon);
        }else{
            System.out.println("El usuario ya contiene el campeÃ³n: "+ usuario.toString());
        }
    }

    /**
     * @return
     */
    public Integer getCantidadCampeones() {

        return campeones.size();
    }

    @Override
    public String toString() {
        return "Jugador{" +
                "nombre='" + nombre + '\'' +
                ", email='" + email + '\'' +
                ", usuario='" + usuario + '\'' +
                ", fechaNacimiento=" + fechaNacimiento +
                '}';
    }
    
    public String ObtenerNombre(){
        return nombre;
    }
}