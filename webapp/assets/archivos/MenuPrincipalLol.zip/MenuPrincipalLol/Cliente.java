

import java.util.*;

/**
 * 
 */
public class Cliente{

    /**
     * Default constructor
     */
    public Cliente() {
        this.listaJugadores = new ArrayList<>();
        this.listaCampeones = new ArrayList<>();
    }
    
    ArrayList<Campeon> listaCampeones;
    ArrayList<Jugador> listaJugadores;
    
    public ArrayList<Jugador> getJugadores(){
        return listaJugadores;
    }
    
    public void agregarJugador(Jugador jugador){
        listaJugadores.add(jugador);
    }
    
    public void agregarCampeon(Campeon campeon){
        listaCampeones.add(campeon);
    }
    
    public String imprimirListaJugadores(){
        String dato = "Jugadores registrados: \n";
        for(Jugador h : listaJugadores){
            dato += h.toString() + "\n";
        }
        return dato;
    }
    
    public String imprimirNombre(){
        String dato2 = "";
        for(Jugador h : listaJugadores){
            dato2 += h.ObtenerNombre() + "\n";
        }
        return dato2;
    }
    
}