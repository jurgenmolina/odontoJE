
public enum Rol {


    LUCHADOR("luchador"),
    TIRADOR("tirador"),
    MAGO("mago"),
    ASESINO("asesino"),
    TANQUE("tanque"),
    APOYO("apoyo");

    private String nombreRol;

    Rol(String nombreRol) {
        this.nombreRol = nombreRol;
    }

    public String getNombreRol() {
        return nombreRol;
    }


    public void setNombreRol(String nombreRol) {
        this.nombreRol = nombreRol;
    }


}