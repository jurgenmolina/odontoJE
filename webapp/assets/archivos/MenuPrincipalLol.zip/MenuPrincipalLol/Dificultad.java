
public enum Dificultad {


    BAJA("baja"),
    MODERADA("moderada"),
    ALTA("alta");

    private  String nombreDificultad;

    Dificultad(String nombreDificultad) {
        this.nombreDificultad = nombreDificultad;
    }

    public String getNombreDificultad() {
        return nombreDificultad;
    }

    public void setNombreDificultad(String nombreDificultad) {
        this.nombreDificultad = nombreDificultad;
    }
}