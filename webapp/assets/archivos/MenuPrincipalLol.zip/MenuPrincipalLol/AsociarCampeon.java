import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Set;
import java.util.HashSet;

public class AsociarCampeon extends JFrame
{
    public JPanel panelEtiqueta, panelEntradas, panelBotones;
    public JLabel jugador, campeon, jugadorGet, titulo;
    public JComboBox boxCampeon;
    public JButton asociarCampeones, volver;
    private Cliente cliente;
    
        public AsociarCampeon(){
            
        setSize(600,400);
        setTitle("Asociar Campeon");
        setResizable(false);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        colocarPanel();
        colocarEtiquetas();
        colocarBotones(); 
        eventos();
    }
    
    public void setJugador(Jugador jugador){
        jugadorGet.setText(jugador.getNombre());
    }
    
    
    
    public void colocarPanel(){
        //Panel Etiqueta
        panelEtiqueta = new JPanel();
        panelEtiqueta.setLayout(new GridLayout(1,1));
        panelEtiqueta.setPreferredSize( new Dimension(5,100));
        add(panelEtiqueta, BorderLayout.NORTH);
        //PanelEntradas
        panelEntradas = new JPanel();
        panelEntradas.setLayout(new GridLayout(2,2));
        panelEntradas.setPreferredSize( new Dimension(5,400));
        add(panelEntradas, BorderLayout.CENTER);
        this.getContentPane().add(panelEntradas);
        
        panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(1,3));
        panelBotones.setPreferredSize( new Dimension(5,100));
        add(panelBotones, BorderLayout.SOUTH);
        
    }
    
    public void colocarEtiquetas(){
        titulo = new JLabel();
        titulo.setText("Asociar Campeon");
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.PLAIN, 20));
        panelEtiqueta.add(titulo);
        
        jugador = new JLabel("Jugador:");
        campeon = new JLabel("Campeon:");
        jugadorGet = new JLabel();
        
        boxCampeon = new JComboBox();
        
        panelEntradas.add(jugador);
        panelEntradas.add(jugadorGet);
        panelEntradas.add(campeon);
        panelEntradas.add(boxCampeon);
    }
    
    public void colocarBotones(){
        asociarCampeones = new JButton();
        asociarCampeones.setText("Asociar Campeon");
        asociarCampeones.setFont(new Font ("cooper black", 0, 20));
        panelBotones.add(asociarCampeones);
        
        volver = new JButton();
        volver.setText("Volver");
        volver.setFont(new Font ("cooper black", 0, 20));
        panelBotones.add(volver);
    }
    
    ActionListener volverAtras = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            DatosBasicosJugador obj = new DatosBasicosJugador();
            obj.setVisible(true);
            dispose();
        }
    
    };
    
    
    public void eventos(){
        volver.addActionListener(volverAtras);
    }
    
}
