import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuPrincipal extends JFrame
{
    public JPanel panel;
    public JLabel titulo;
    public JButton botonDatosJugador, botonRegistrarCampeones, botonImprimirDatosJugador;
    
    
        public MenuPrincipal(){
        setSize(300,300);
        setTitle("Menu Principal");
        setResizable(false);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        colocarPanel();
        colocarEtiquetas();
        colocarBotones();
        eventos();
        
        setVisible(true);
    }
    
    public void colocarPanel(){
        panel = new JPanel();
        setLayout(new GridLayout(1,4));
        setPreferredSize( new Dimension(5,250));
        
        this.getContentPane().add(panel);
    }
    
    public void colocarEtiquetas(){
        titulo = new JLabel();
        titulo.setText("Menu Principal LOL");
        titulo.setFont(new Font("Arial", Font.PLAIN, 20));
        panel.add(titulo);
    }
    
    public void colocarBotones(){
        botonDatosJugador = new JButton();
        botonDatosJugador.setText("Datos del jugador");
        botonDatosJugador.setFont(new Font ("cooper black", 0, 20));
        panel.add(botonDatosJugador);
        
        botonRegistrarCampeones = new JButton();
        botonRegistrarCampeones.setText("Registrar campeones");
        botonRegistrarCampeones.setFont(new Font ("cooper black", 0, 20));
        panel.add(botonRegistrarCampeones);
        
        botonImprimirDatosJugador = new JButton();
        botonImprimirDatosJugador.setText("Imprimir datos del jugador");
        botonImprimirDatosJugador.setFont(new Font ("cooper black", 0, 20));
        panel.add(botonImprimirDatosJugador);
    }
    
    ActionListener datosJugador = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            DatosBasicosJugador obj = new DatosBasicosJugador();
            obj.setVisible(true);
            dispose();
        }
    
    };
    
    ActionListener registrarCampeones = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            RegistrarCampeones obj = new RegistrarCampeones();
            obj.setVisible(true);
            dispose();
        }
    
    };
    
    ActionListener imprimirDatosJugador = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            ImprimirDatosJugador obj = new ImprimirDatosJugador();
            obj.setVisible(true);
            dispose();
        }
    
    };
    
    public void eventos(){
        botonDatosJugador.addActionListener(datosJugador);
        botonRegistrarCampeones.addActionListener(registrarCampeones);
        botonImprimirDatosJugador.addActionListener(imprimirDatosJugador);
    }
}
