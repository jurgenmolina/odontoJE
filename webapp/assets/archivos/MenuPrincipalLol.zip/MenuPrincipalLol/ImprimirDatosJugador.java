import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ImprimirDatosJugador extends JFrame
{
    public JPanel panelEtiqueta, panelEntradas, panelBotones;
    public JLabel jugador, campeon, jugadorGet, titulo;
    public JTextField txtListCampeones;
    public JButton volver;
    private JScrollPane scrollpane1;
    
        public ImprimirDatosJugador(){
        setSize(400,400);
        setTitle("Imprimir Datos Jugador");
        setResizable(false);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        colocarPanel();
        colocarEtiquetas();
        colocarBotones();
        eventos();
        
        setVisible(true);  
    }
    
    public void colocarPanel(){
        //Panel Etiqueta
        panelEtiqueta = new JPanel();
        panelEtiqueta.setLayout(new GridLayout(1,1));
        panelEtiqueta.setPreferredSize( new Dimension(5,100));
        add(panelEtiqueta, BorderLayout.NORTH);
        //PanelEntradas
        panelEntradas = new JPanel();
        panelEntradas.setLayout(new GridLayout(2,2));
        panelEntradas.setPreferredSize( new Dimension(5,200));
        add(panelEntradas, BorderLayout.CENTER);
        this.getContentPane().add(panelEntradas);
        
        panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(1,1));
        panelBotones.setPreferredSize( new Dimension(5,100));
        add(panelBotones, BorderLayout.SOUTH);
        
    }
    
    public void colocarEtiquetas(){
        titulo = new JLabel();
        titulo.setText("Datos del jugador");
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.PLAIN, 20));
        panelEtiqueta.add(titulo);
        
        jugador = new JLabel("Nombre:");
        campeon = new JLabel("Campeon:");
        jugadorGet = new JLabel();
        
        txtListCampeones = new JTextField();
        
        scrollpane1=new JScrollPane(txtListCampeones);
        
        
        panelEntradas.add(jugador);
        panelEntradas.add(jugadorGet);
        panelEntradas.add(campeon);
        panelEntradas.add(scrollpane1);
        
    }
    
    public void colocarBotones(){
        volver = new JButton();
        volver.setText("Volver");
        volver.setFont(new Font ("cooper black", 0, 20));
        volver.setHorizontalAlignment(SwingConstants.CENTER);
        panelBotones.add(volver);
    }
    
    ActionListener volverAtras = new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            MenuPrincipal obj = new MenuPrincipal();
            obj.setVisible(true);
            dispose();
        }
    
    };
    
    
    public void eventos(){
        
        volver.addActionListener(volverAtras);
    }
}
