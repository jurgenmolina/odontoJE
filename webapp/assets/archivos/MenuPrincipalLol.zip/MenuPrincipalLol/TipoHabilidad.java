
public enum TipoHabilidad {

    ACTIVA("activa"),
    PASIVA("pasiva"),
    POSICION("posicion");

    private String nombreTipoHabilidad;

    TipoHabilidad(String nombreTipoHabilidad) {
        this.nombreTipoHabilidad = nombreTipoHabilidad;
    }

    public String getNombreTipoHabilidad() {
        return nombreTipoHabilidad;
    }

    public void setNombreTipoHabilidad(String nombreTipoHabilidad) {
        this.nombreTipoHabilidad = nombreTipoHabilidad;
    }
}